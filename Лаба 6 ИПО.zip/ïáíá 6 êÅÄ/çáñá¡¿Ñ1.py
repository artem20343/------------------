temp = [11, 18, 20, 25]
at = sum(temp) / len(temp)
print("Средняя температура на 3-й метеостанции:", at)